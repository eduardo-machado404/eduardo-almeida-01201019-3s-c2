package br.com.bandtec.ac2luta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ac2LutaApplicationTests {

	@Test
	void contextLoads() {
	}

}
