package br.com.bandtec.ac2luta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ac2LutaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ac2LutaApplication.class, args);
	}

}
